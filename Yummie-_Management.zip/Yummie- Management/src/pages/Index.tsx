import DashboardSelector from "./DashboardSelector";

const Index = () => {
  return <DashboardSelector />;
};

export default Index;
